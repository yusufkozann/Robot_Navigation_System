# Robot_Navigation_System
This repository contains the Robot_Navigation_System1.simstage_group2 ROS package, developed to simulate robot navigation in a virtual environment using ROS. The package includes a reactive navigation strategy, SLAM-based mapping, and rviz visualization features.
